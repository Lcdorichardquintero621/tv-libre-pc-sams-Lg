# TV Libre – PC (Windows)
Proyecto independiente (Electron). Compila a TVLibre-PC.exe (portátil, sin instalar).
Para probar con Node: npm install && npm start
