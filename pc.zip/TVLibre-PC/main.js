const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');

// Permite reproducir sin que el usuario tenga que tocar el video primero
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    backgroundColor: '#0f1420',
    autoHideMenuBar: true,
    webPreferences: {
      // La app solo carga sus propios archivos locales; se desactiva la restricción de
      // dominios cruzados para poder leer las listas de canales y comprobar los streams.
      webSecurity: false,
      allowRunningInsecureContent: true,
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
