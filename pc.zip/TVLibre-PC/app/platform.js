window.TVL = { platform: 'pc', tv: false };
