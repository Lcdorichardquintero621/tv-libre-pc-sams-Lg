/* TV Libre – app web (PC, LG webOS, Samsung Tizen). Sin async/await ni sintaxis moderna para TVs antiguos. */
(function () {
  'use strict';
  var TVL = window.TVL || { platform: 'web', tv: false };

  // ---------- Constantes ----------
  var BASE = 'https://iptv-org.github.io/iptv';
  var FAV = '★ Favoritos';
  var DEFAULT = 'Todos en español';
  var LIST_PREFIX = 'Lista: ';
  var COUNTRIES = ['ve', 'ec', 'pe', 'co', 'mx', 'ar', 'cl', 'bo', 'py', 'uy', 'cr', 'pa', 'gt', 'hn', 'ni', 'sv',
    'do', 'cu', 'pr', 'es', 'us'];
  var NAMES = { ve: 'Venezuela', ec: 'Ecuador', pe: 'Perú', co: 'Colombia', mx: 'México', ar: 'Argentina',
    cl: 'Chile', bo: 'Bolivia', py: 'Paraguay', uy: 'Uruguay', cr: 'Costa Rica', pa: 'Panamá',
    gt: 'Guatemala', hn: 'Honduras', ni: 'Nicaragua', sv: 'El Salvador', 'do': 'Rep. Dominicana', cu: 'Cuba',
    pr: 'Puerto Rico', es: 'España', us: 'Estados Unidos', br: 'Brasil', fr: 'Francia', de: 'Alemania',
    it: 'Italia', gb: 'Reino Unido', uk: 'Reino Unido', pt: 'Portugal', ru: 'Rusia', jp: 'Japón',
    kr: 'Corea del Sur', at: 'Austria', au: 'Australia', nz: 'Nueva Zelanda', ie: 'Irlanda' };
  var LANGS = { spa: 'Español', es: 'Español', spanish: 'Español', eng: 'Inglés', en: 'Inglés', english: 'Inglés',
    fre: 'Francés', fra: 'Francés', fr: 'Francés', french: 'Francés', ger: 'Alemán', deu: 'Alemán', de: 'Alemán',
    german: 'Alemán', ita: 'Italiano', it: 'Italiano', italian: 'Italiano', por: 'Portugués', pt: 'Portugués',
    portuguese: 'Portugués', rus: 'Ruso', ru: 'Ruso', russian: 'Ruso', jpn: 'Japonés', ja: 'Japonés',
    japanese: 'Japonés', chi: 'Chino', zho: 'Chino', zh: 'Chino', chinese: 'Chino', ara: 'Árabe', ar: 'Árabe',
    arabic: 'Árabe', kor: 'Coreano', ko: 'Coreano', korean: 'Coreano' };
  var ES_SET = 'pe mx es ar co cl ve ec bo uy py cr pa gt hn ni sv do cu pr'.split(' ');
  var EN_SET = 'us gb uk au nz ie'.split(' ');

  // ---------- Utilidades ----------
  function $(id) { return document.getElementById(id); }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  }
  function norm(s) { return (s || '').toLowerCase(); }
  function hasClass(e, c) { return (' ' + e.className + ' ').indexOf(' ' + c + ' ') >= 0; }
  function show(e, on) { if (on) { e.className = e.className.replace(/\bhidden\b/g, '').trim(); } else if (!hasClass(e, 'hidden')) { e.className += ' hidden'; } }
  function withTimeout(p, ms) {
    return new Promise(function (res, rej) {
      var t = setTimeout(function () { rej(new Error('timeout')); }, ms);
      p.then(function (v) { clearTimeout(t); res(v); }, function (e) { clearTimeout(t); rej(e); });
    });
  }
  function getText(url, ms) {
    return withTimeout(fetch(url), ms || 30000).then(function (r) {
      if (!r.ok) throw new Error('http ' + r.status);
      return r.text();
    });
  }
  var toastTimer = null;
  function toast(msg) {
    var t = $('toast');
    t.textContent = msg; show(t, true);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { show(t, false); }, 3000);
  }

  // ---------- País e idioma ----------
  function fixCc(cc) { return cc === 'uk' ? 'gb' : cc; }
  function countryName(cc) { return cc ? (NAMES[fixCc(cc)] || cc.toUpperCase()) : ''; }
  function langName(raw) {
    var first = (raw || '').split(/[;,\/]/)[0].trim();
    if (!first) return '';
    var k = first.toLowerCase();
    if (LANGS[k]) return LANGS[k];
    return first.length <= 3 ? first.toUpperCase() : first.charAt(0).toUpperCase() + first.slice(1);
  }
  function mainLang(cc) {
    if (ES_SET.indexOf(cc) >= 0) return 'Español';
    if (EN_SET.indexOf(cc) >= 0) return 'Inglés';
    if (cc === 'br' || cc === 'pt') return 'Portugués';
    if (cc === 'fr') return 'Francés';
    if (cc === 'de' || cc === 'at') return 'Alemán';
    if (cc === 'it') return 'Italiano';
    if (cc === 'ru') return 'Ruso';
    if (cc === 'jp') return 'Japonés';
    if (cc === 'kr') return 'Coreano';
    return '';
  }

  // ---------- Listas M3U e Internet Archive ----------
  function attr(line, key) {
    var m = new RegExp(key + '="([^"]*)"').exec(line);
    return m ? m[1].trim() : '';
  }
  function parseM3U(text, defLang) {
    var out = [], lines = text.split(/\r?\n/), name = null, group = '', logo = '', cc = '', lang = '';
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (line.indexOf('#EXTINF') === 0) {
        var c = line.lastIndexOf(',');
        name = c >= 0 ? line.slice(c + 1).trim() : '';
        group = attr(line, 'group-title');
        logo = attr(line, 'tvg-logo');
        var m = /\.([A-Za-z]{2})(@.*)?$/.exec(attr(line, 'tvg-id'));
        cc = m ? m[1].toLowerCase() : '';
        if (!cc) {
          var t = attr(line, 'tvg-country');
          if (t.length >= 2 && /^[A-Za-z]{2}/.test(t)) cc = t.slice(0, 2).toLowerCase();
        }
        var l = attr(line, 'tvg-language');
        lang = l ? langName(l) : (defLang || mainLang(cc));
      } else if (line && line.charAt(0) !== '#' && name !== null) {
        if (line.indexOf('http') === 0) {
          out.push({ name: name || 'Sin nombre', group: group || 'General', url: line, logo: logo, country: cc, lang: lang });
        }
        name = null; group = ''; logo = ''; cc = ''; lang = '';
      }
    }
    return out;
  }
  function searchIA(q) {
    var u = 'https://archive.org/advancedsearch.php?q=' + encodeURIComponent(q) +
      '&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=year&fl%5B%5D=language' +
      '&sort%5B%5D=downloads+desc&rows=200&output=json';
    return getText(u).then(function (t) {
      var docs = JSON.parse(t).response.docs, out = [];
      docs.forEach(function (d) {
        if (!d.identifier) return;
        var title = Array.isArray(d.title) ? d.title[0] : d.title;
        var lg = Array.isArray(d.language) ? d.language[0] : d.language;
        out.push({ name: title || d.identifier, group: d.year ? String(d.year) : 'Internet Archive',
          url: 'ia://' + d.identifier, logo: 'https://archive.org/services/img/' + d.identifier,
          country: '', lang: langName(lg || '') });
      });
      return out;
    });
  }
  function iaUrl(id, n) {
    return 'https://archive.org/download/' + encodeURIComponent(id) + '/' + n.split('/').map(encodeURIComponent).join('/');
  }
  function resolveIA(id) {
    return getText('https://archive.org/metadata/' + encodeURIComponent(id), 20000).then(function (t) {
      var files = JSON.parse(t).files || [], fb = null;
      for (var i = 0; i < files.length; i++) {
        var n = files[i].name || '';
        if (!/\.mp4$/i.test(n)) continue;
        if (/h\.264/i.test(files[i].format || '')) return iaUrl(id, n);
        if (!fb) fb = n;
      }
      return fb ? iaUrl(id, fb) : null;
    });
  }

  // ---------- Verificación de canales (✓ / ✕) ----------
  var status = {};            // url -> 0 comprobando, 1 funciona, 2 falla
  var queue = [], running = 0, MAXRUN = 10, done = 0, okCount = 0, netErr = 0, blocked = false;

  function checkChannel(ch) {
    if (ch.url.indexOf('ia://') === 0) {
      return resolveIA(ch.url.slice(5)).then(function (u) { return { ok: !!u }; }, function () { return { ok: false }; });
    }
    var ac = window.AbortController ? new AbortController() : null;
    var opts = ac ? { signal: ac.signal } : {};
    function stop() { try { if (ac) ac.abort(); } catch (e) { /* nada */ } }
    return withTimeout(fetch(ch.url, opts), 7000).then(function (r) {
      if (!r.ok) { stop(); return { ok: false }; }
      var ct = (r.headers.get('content-type') || '').toLowerCase();
      var playlist = /m3u8/i.test(ch.url) || ct.indexOf('mpegurl') >= 0;
      if (!playlist) { stop(); return { ok: true }; }
      return withTimeout(r.text(), 7000).then(function (t) { return { ok: /^\s*#EXTM3U/.test(t) }; });
    }, function () { stop(); return { ok: false, neterr: true }; });
  }
  function request(ch, cb) {
    if (blocked || status[ch.url] !== undefined) return;
    status[ch.url] = 0;
    queue.push({ ch: ch, cb: cb });
    pump();
  }
  function pump() {
    while (running < MAXRUN && queue.length) {
      var job = queue.pop();           // los últimos en pedirse (los visibles) se revisan primero
      running++;
      (function (j) {
        checkChannel(j.ch).then(function (r) {
          running--; done++;
          if (r.ok) okCount++;
          if (r.neterr) netErr++;
          if (!blocked && done >= 12 && okCount === 0 && netErr >= 10) {
            // Casi seguro que el navegador bloquea la comprobación (CORS): no mostrar falsos ✕
            blocked = true; status = {}; queue = [];
            onBlocked();
          } else if (!blocked) {
            status[j.ch.url] = r.ok ? 1 : 2;
          }
          if (j.cb) j.cb();
          pump();
        });
      })(job);
    }
  }
  function markStatus(url, v) { status[url] = v; scheduleRefresh(); }
  function onBlocked() {
    onlyOk = false;
    show($('btnOk'), false);
    toast('Este dispositivo no permite verificar canales; se ocultan los ✓');
    applyFilter();
  }

  // ---------- Favoritos y listas personalizadas ----------
  var lists = {}, custom = '';
  try { lists = JSON.parse(localStorage.getItem('tvlibre.lists') || '{}') || {}; } catch (e) { lists = {}; }
  if (!lists[FAV]) lists[FAV] = [];
  try { custom = localStorage.getItem('tvlibre.custom') || ''; } catch (e) { custom = ''; }
  function saveLists() { try { localStorage.setItem('tvlibre.lists', JSON.stringify(lists)); } catch (e) { /* nada */ } }
  function listNames() {
    var n = [FAV];
    Object.keys(lists).forEach(function (k) { if (k !== FAV) n.push(k); });
    return n;
  }
  function inList(name, ch) { return (lists[name] || []).some(function (c) { return c.url === ch.url; }); }
  function addTo(name, ch) {
    if (!lists[name]) lists[name] = [];
    if (!inList(name, ch)) {
      lists[name].push({ name: ch.name, group: ch.group, url: ch.url, logo: ch.logo, country: ch.country, lang: ch.lang });
    }
    saveLists();
  }
  function removeFrom(name, ch) {
    lists[name] = (lists[name] || []).filter(function (c) { return c.url !== ch.url; });
    saveLists();
  }
  function listNameOf(label) {
    if (label === FAV) return FAV;
    if (label.indexOf(LIST_PREFIX) === 0 && lists[label.slice(LIST_PREFIX.length)]) return label.slice(LIST_PREFIX.length);
    return null;
  }

  // ---------- Fuentes ----------
  function buildSources() {
    var s = [{ label: DEFAULT, kind: 'm3u', ref: BASE + '/languages/spa.m3u', defLang: 'Español' }];
    COUNTRIES.forEach(function (cc) {
      s.push({ label: NAMES[cc], kind: 'm3u', ref: BASE + '/countries/' + cc + '.m3u', country: true });
    });
    s.push({ label: 'Películas clásicas', kind: 'ia', ref: 'collection:feature_films AND mediatype:movies' });
    s.push({ label: 'Películas en español', kind: 'ia', ref: 'collection:feature_films AND mediatype:movies AND (language:Spanish OR language:spa)' });
    s.push({ label: 'Ciencia ficción y terror', kind: 'ia', ref: 'collection:SciFi_Horror AND mediatype:movies' });
    s.push({ label: 'Cine mudo', kind: 'ia', ref: 'collection:silent_films AND mediatype:movies' });
    s.push({ label: 'TV clásica', kind: 'ia', ref: 'collection:classic_tv AND mediatype:movies' });
    if (custom) s.push({ label: 'Mi lista M3U', kind: 'm3u', ref: custom });
    return s;
  }
  var sources = buildSources();
  function findSource(label) {
    for (var i = 0; i < sources.length; i++) if (sources[i].label === label) return sources[i];
    return null;
  }

  // ---------- Estado de la pantalla principal ----------
  var all = [], shown = [], rendered = 0, PAGE = 60, onlyOk = false, busy = false, reqId = 0;
  var currentLabel = DEFAULT, refreshTimer = null;
  var appEl, gridEl, searchEl, countEl, emptyEl, chips1, chips2, modalEl, playerEl, video;

  function renderChips() {
    chips1.innerHTML = ''; chips2.innerHTML = '';
    function add(parent, label, text) {
      var b = el('button', 'f chip' + (label === currentLabel ? ' on' : ''), text || label);
      b.onclick = function () { select(label); };
      parent.appendChild(b);
    }
    listNames().forEach(function (n) { add(chips1, n === FAV ? FAV : LIST_PREFIX + n); });
    sources.forEach(function (s) { add(s.country ? chips2 : chips1, s.label); });
  }
  function select(label) {
    currentLabel = label;
    renderChips();
    load(label);
    var cs = chips1.children.length ? document.querySelectorAll('.chip.on') : [];
    if (cs.length) { try { cs[0].focus(); } catch (e) { /* nada */ } }
  }
  function setBusy(b) { busy = b; }
  function load(label) {
    var id = ++reqId, ln = listNameOf(label);
    if (ln) { all = (lists[ln] || []).slice(); setBusy(false); applyFilter(); return; }
    var s = findSource(label);
    if (!s) return;
    setBusy(true); all = []; applyFilter();
    var p = s.kind === 'ia' ? searchIA(s.ref) : getText(s.ref).then(function (t) { return parseM3U(t, s.defLang || ''); });
    p.then(function (list) {
      if (id !== reqId) return;
      all = list; setBusy(false); applyFilter();
    }, function () {
      if (id !== reqId) return;
      all = []; setBusy(false); applyFilter(); toast('No se pudo cargar la lista');
    });
  }

  function applyFilter() {
    if (onlyOk && !blocked) verifyAll();
    var q = norm(searchEl.value.trim());
    var list = !q ? all.slice() : all.filter(function (c) {
      return norm(c.name).indexOf(q) >= 0 || norm(c.group).indexOf(q) >= 0 ||
        norm(countryName(c.country)).indexOf(q) >= 0 || norm(c.lang).indexOf(q) >= 0;
    });
    var pending = 0;
    if (onlyOk && !blocked) {
      list.forEach(function (c) { if (!status[c.url]) pending++; });
      list = list.filter(function (c) { return status[c.url] === 1; });
    }
    shown = list;
    renderGrid();
    countEl.textContent = (onlyOk && !blocked)
      ? list.length + ' funcionan' + (pending ? ' · verificando ' + pending + '…' : '')
      : list.length + ' resultados';
    emptyEl.textContent = busy ? 'Cargando…'
      : (onlyOk && pending ? 'Verificando canales… irán apareciendo los que funcionan' : 'Nada por aquí todavía');
    show(emptyEl, list.length === 0);
  }
  function verifyAll() { all.forEach(function (c) { request(c, scheduleRefresh); }); }
  function scheduleRefresh() {
    if (refreshTimer) return;
    refreshTimer = setTimeout(function () {
      refreshTimer = null;
      if (onlyOk && !blocked) applyFilter(); else refreshBadges();
    }, 800);
  }
  function setBadge(b, url) {
    var s = status[url];
    if (s === undefined) { b.className = 'st none'; b.textContent = ''; }
    else if (s === 0) { b.className = 'st wait'; b.textContent = '…'; }
    else if (s === 1) { b.className = 'st ok'; b.textContent = '✓'; }
    else { b.className = 'st bad'; b.textContent = '✕'; }
  }
  function refreshBadges() {
    var cs = gridEl.children;
    for (var i = 0; i < cs.length; i++) setBadge(cs[i].querySelector('.st'), cs[i].getAttribute('data-url'));
  }

  function focusedCardUrl() {
    var a = document.activeElement;
    var c = a && a.closest ? a.closest('.card') : null;
    return c ? c.getAttribute('data-url') : null;
  }
  function focusNoScroll(e) { try { e.focus({ preventScroll: true }); } catch (x) { e.focus(); } }
  function renderGrid() {
    var keep = focusedCardUrl();
    gridEl.innerHTML = ''; rendered = 0;
    renderMore();
    if (keep) {
      var cs = gridEl.children;
      for (var i = 0; i < cs.length; i++) if (cs[i].getAttribute('data-url') === keep) { focusNoScroll(cs[i]); break; }
    }
  }
  function renderMore() {
    var end = Math.min(shown.length, rendered + PAGE), frag = document.createDocumentFragment();
    for (var i = rendered; i < end; i++) frag.appendChild(makeCard(shown[i]));
    rendered = end;
    gridEl.appendChild(frag);
  }
  function infoText(ch) {
    var p = [];
    if (ch.country) p.push(countryName(ch.country));
    if (ch.lang) p.push(ch.lang);
    return p.join(' · ');
  }
  function makeCard(ch) {
    var c = el('div', 'card f');
    c.tabIndex = 0;
    c.setAttribute('data-url', ch.url);
    var img = el('img', 'thumb');
    img.alt = '';
    if (ch.logo) { img.src = ch.logo; img.onerror = function () { img.style.visibility = 'hidden'; }; }
    else img.style.visibility = 'hidden';
    var meta = el('div', 'meta');
    meta.appendChild(el('div', 'name', ch.name));
    meta.appendChild(el('div', 'info', infoText(ch)));
    meta.appendChild(el('div', 'group', ch.group));
    var st = el('span', 'st');
    setBadge(st, ch.url);
    var star = el('button', 'star f', inList(FAV, ch) ? '★' : '☆');
    star.onclick = function (e) { e.stopPropagation(); toggleFav(ch, star); };
    var mn = el('button', 'menu f', '⋮');
    mn.onclick = function (e) { e.stopPropagation(); showListsDialog(ch); };
    c.appendChild(img); c.appendChild(meta); c.appendChild(st); c.appendChild(star); c.appendChild(mn);
    c.onclick = function () { var i = shown.indexOf(ch); openPlayer(shown, i < 0 ? 0 : i, currentLabel); };
    request(ch, scheduleRefresh);
    return c;
  }
  function toggleFav(ch, star) {
    if (inList(FAV, ch)) { removeFrom(FAV, ch); toast('Quitado de ' + FAV); }
    else { addTo(FAV, ch); toast('Agregado a ' + FAV); }
    star.textContent = inList(FAV, ch) ? '★' : '☆';
    if (listNameOf(currentLabel)) { all = lists[listNameOf(currentLabel)].slice(); applyFilter(); }
  }

  // ---------- Ventanas (modales) ----------
  var lastFocus = null;
  function modalOpen() { return hasClass(modalEl, 'show'); }
  function openModal(title, build, buttons) {
    if (!modalOpen()) lastFocus = document.activeElement;
    modalEl.innerHTML = '';
    var box = el('div', 'modal-box');
    box.appendChild(el('h2', '', title));
    var list = el('div', 'modal-list');
    box.appendChild(list);
    var act = el('div', 'modal-actions');
    (buttons || []).forEach(function (b) {
      var x = el('button', 'btn f', b.label);
      x.onclick = b.fn;
      act.appendChild(x);
    });
    box.appendChild(act);
    modalEl.appendChild(box);
    modalEl.className = 'show';
    if (build) build(box, list);
    setTimeout(function () {
      var first = list.querySelector('.cur') || list.querySelector('.f') || act.querySelector('.f');
      if (first) { first.focus(); ensureVisible(first); }
    }, 0);
  }
  function closeModal() {
    modalEl.className = ''; modalEl.innerHTML = '';
    if (lastFocus && document.body.contains(lastFocus)) { try { lastFocus.focus(); } catch (e) { /* nada */ } }
  }
  function askText(title, ph, val) {
    return new Promise(function (resolve) {
      var input = el('input', 'f');
      input.type = 'text'; input.placeholder = ph; input.value = val || '';
      function ok() { var v = input.value.trim(); closeModal(); resolve(v); }
      openModal(title, function (box, list) { list.appendChild(input); }, [
        { label: 'Aceptar', fn: ok },
        { label: 'Cancelar', fn: function () { closeModal(); resolve(''); } }
      ]);
      input.addEventListener('keydown', function (e) { if (e.keyCode === 13) { e.preventDefault(); ok(); } });
    });
  }
  function createList(n) {
    if (n && n !== FAV && !lists[n]) { lists[n] = []; saveLists(); renderChips(); }
  }
  function showListsDialog(ch) {
    var focusIdx = 0;
    openModal(ch.name, function (box, list) {
      function rebuild() {
        list.innerHTML = '';
        listNames().forEach(function (n, idx) {
          var b = el('button', 'row f', (inList(n, ch) ? '☑  ' : '☐  ') + n);
          b.onclick = function () {
            if (inList(n, ch)) removeFrom(n, ch); else addTo(n, ch);
            focusIdx = idx; rebuild();
            if (list.children[idx]) list.children[idx].focus();
            refreshStars();
            if (listNameOf(currentLabel)) { all = lists[listNameOf(currentLabel)].slice(); applyFilter(); }
          };
          list.appendChild(b);
        });
      }
      rebuild();
    }, [
      { label: '+ Nueva lista', fn: function () {
        closeModal();
        askText('Nueva lista', 'Nombre de la lista', '').then(function (n) {
          if (n) { createList(n); addTo(n, ch); }
          showListsDialog(ch);
        });
      } },
      { label: 'Cerrar', fn: closeModal }
    ]);
  }
  function refreshStars() {
    var cs = gridEl.children;
    for (var i = 0; i < cs.length; i++) {
      var url = cs[i].getAttribute('data-url');
      var st = cs[i].querySelector('.star');
      if (st) st.textContent = lists[FAV].some(function (c) { return c.url === url; }) ? '★' : '☆';
    }
  }
  function showMenu() {
    openModal('Listas', function (box, list) {
      function row(text, fn) { var b = el('button', 'row f', text); b.onclick = fn; list.appendChild(b); }
      row('Nueva lista', function () {
        closeModal();
        askText('Nueva lista', 'Nombre de la lista', '').then(function (n) { if (n) { createList(n); select(LIST_PREFIX + n); } });
      });
      row('Eliminar lista actual', function () {
        var ln = listNameOf(currentLabel);
        closeModal();
        if (!ln || ln === FAV) { toast('Elige primero una de tus listas'); return; }
        openModal('Eliminar "' + ln + '"', function (b2, l2) { l2.appendChild(el('div', '', 'Se borrará la lista y su contenido guardado.')); }, [
          { label: 'Eliminar', fn: function () { delete lists[ln]; saveLists(); closeModal(); select(FAV); } },
          { label: 'Cancelar', fn: closeModal }
        ]);
      });
      row('Agregar lista M3U (URL)', function () {
        closeModal();
        askText('URL de lista M3U', 'https://...lista.m3u', custom).then(function (u) {
          if (u && /^https?:\/\//i.test(u)) {
            custom = u;
            try { localStorage.setItem('tvlibre.custom', u); } catch (e) { /* nada */ }
            sources = buildSources();
            select('Mi lista M3U');
          } else if (u) { toast('URL no válida'); }
        });
      });
    }, [{ label: 'Cerrar', fn: closeModal }]);
  }

  // ---------- Navegación con control remoto ----------
  function visible(e) { return e.offsetWidth > 0 && e.offsetHeight > 0; }
  function ensureVisible(e) {
    var r = e.getBoundingClientRect();
    var sc = e.closest ? e.closest('.modal-list') : null;
    if (sc) {
      var cr = sc.getBoundingClientRect();
      if (r.top < cr.top) sc.scrollTop -= (cr.top - r.top) + 8;
      else if (r.bottom > cr.bottom) sc.scrollTop += (r.bottom - cr.bottom) + 8;
      return;
    }
    var ch = e.closest ? e.closest('.chips') : null;
    if (ch) {
      var cr2 = ch.getBoundingClientRect();
      if (r.left < cr2.left) ch.scrollLeft -= (cr2.left - r.left) + 24;
      else if (r.right > cr2.right) ch.scrollLeft += (r.right - cr2.right) + 24;
    }
    if (hasClass(playerEl, 'hidden')) {
      if (r.top < 70) window.scrollBy(0, r.top - 100);
      else if (r.bottom > window.innerHeight - 20) window.scrollBy(0, r.bottom - window.innerHeight + 40);
    }
  }
  function moveFocus(dir, scope) {
    var els = Array.prototype.slice.call(scope.querySelectorAll('.f')).filter(visible);
    var cur = document.activeElement;
    if (!cur || els.indexOf(cur) < 0) { if (els.length) { els[0].focus(); ensureVisible(els[0]); } return; }
    var r = cur.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, best = null, bs = 1e12;
    els.forEach(function (e) {
      if (e === cur) return;
      var b = e.getBoundingClientRect(), dx = b.left + b.width / 2 - cx, dy = b.top + b.height / 2 - cy, s;
      if (dir === 'right') { if (dx <= 5) return; s = dx + 2.5 * Math.abs(dy); }
      else if (dir === 'left') { if (dx >= -5) return; s = -dx + 2.5 * Math.abs(dy); }
      else if (dir === 'down') { if (dy <= 5) return; s = dy + 2.5 * Math.abs(dx); }
      else { if (dy >= -5) return; s = -dy + 2.5 * Math.abs(dx); }
      if (s < bs) { bs = s; best = e; }
    });
    if (!best && dir === 'down' && scope === appEl && rendered < shown.length) { renderMore(); moveFocus(dir, scope); return; }
    if (best) { best.focus(); ensureVisible(best); }
  }
  function dirOf(k) { return k === 37 ? 'left' : k === 38 ? 'up' : k === 39 ? 'right' : k === 40 ? 'down' : null; }
  function isBack(k) { return k === 10009 || k === 461 || k === 27; }
  function exitApp() {
    try { if (window.tizen) { window.tizen.application.getCurrentApplication().exit(); return; } } catch (e) { /* nada */ }
    try { window.close(); } catch (e2) { /* nada */ }
  }

  // ---------- Reproductor ----------
  var P = { items: [], index: 0, zapping: false, lastDir: 1, autoSkips: 0, hls: null, startTimer: null,
    ctrlTimer: null, bannerTimer: null, loadId: 0, errId: -1, movie: false, mainFocus: null };

  function playerOpen() { return !hasClass(playerEl, 'hidden'); }
  function controlsVisible() { return !hasClass($('controls'), 'hidden'); }
  function showSpin(on) { show($('spin'), on); }
  function showBanner(t) {
    var b = $('banner');
    b.textContent = t; show(b, true);
    clearTimeout(P.bannerTimer);
    P.bannerTimer = setTimeout(function () { show(b, false); }, 2800);
  }
  function showControls(focusPlay) {
    show($('controls'), true);
    clearTimeout(P.ctrlTimer);
    P.ctrlTimer = setTimeout(hideControls, 4500);
    if (focusPlay) $('pPlay').focus();
  }
  function hideControls() {
    show($('controls'), false);
    clearTimeout(P.ctrlTimer);
    var a = document.activeElement;
    if (a && a.blur && $('controls').contains(a)) a.blur();
  }
  function isVod() { return isFinite(video.duration) && video.duration > 0; }
  function fmt(t) {
    t = Math.max(0, Math.floor(t || 0));
    var h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
    return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }

  function openPlayer(list, idx, label) {
    if (!list.length) return;
    P.items = list; P.label = label; P.zapping = false; P.autoSkips = 0;
    P.mainFocus = document.activeElement;
    show(playerEl, true);
    document.body.className = 'noscroll';
    playIndex(idx);
    if (!TVL.tv) showControls(false);   // en TV los controles salen con OK y las flechas cambian de canal
  }
  function closePlayer() {
    clearTimeout(P.startTimer); P.loadId++;
    destroyHls();
    try { video.pause(); video.removeAttribute('src'); video.load(); } catch (e) { /* nada */ }
    hideControls(); show(playerEl, false);
    document.body.className = '';
    try { if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen(); } catch (e2) { /* nada */ }
    if (P.mainFocus && document.body.contains(P.mainFocus)) focusNoScroll(P.mainFocus);
    refreshBadges();
  }
  function destroyHls() { if (P.hls) { try { P.hls.destroy(); } catch (e) { /* nada */ } P.hls = null; } }

  function playIndex(i) {
    P.index = i;
    var ch = P.items[i], id = ++P.loadId;
    $('pTitle').textContent = ch.name;
    showBanner((i + 1) + '/' + P.items.length + ' · ' + ch.name);
    clearTimeout(P.startTimer); destroyHls();
    if (ch.url.indexOf('ia://') === 0) {
      showSpin(true);
      resolveIA(ch.url.slice(5)).then(function (u) {
        if (id !== P.loadId) return;
        if (!u) { showSpin(false); showBanner('No se encontró un video reproducible'); return; }
        startUrl(u, true);
      }, function () {
        if (id !== P.loadId) return;
        showSpin(false); showBanner('No se pudo preparar la película');
      });
    } else {
      startUrl(ch.url, false);
    }
  }
  function startUrl(url, movie) {
    P.movie = movie;
    showSpin(true);
    if (!movie) {
      var id = P.loadId;
      P.startTimer = setTimeout(function () { if (id === P.loadId) onPlayError(); }, 15000);
    }
    var nativeHls = video.canPlayType && video.canPlayType('application/vnd.apple.mpegurl');
    if (/m3u8/i.test(url) && window.Hls && window.Hls.isSupported() && !nativeHls) {
      P.hls = new window.Hls({ enableWorker: true });
      P.hls.on(window.Hls.Events.ERROR, function (e, d) { if (d && d.fatal) onPlayError(); });
      P.hls.loadSource(url);
      P.hls.attachMedia(video);
    } else {
      video.src = url;
    }
    var pr = video.play();
    if (pr && pr.catch) pr.catch(function () { /* el usuario puede pulsar play */ });
  }
  function onPlayError() {
    if (!playerOpen() || P.errId === P.loadId) return;
    P.errId = P.loadId;
    clearTimeout(P.startTimer); showSpin(false);
    var ch = P.items[P.index], movie = ch.url.indexOf('ia://') === 0;
    if (!movie) markStatus(ch.url, 2);
    if (P.zapping && !movie && P.autoSkips < 6 && P.items.length > 1) {
      P.autoSkips++;
      showBanner('Canal caído, probando el siguiente…');
      step(P.lastDir);
    } else {
      showBanner('No se pudo reproducir este canal (puede estar caído o bloqueado)');
    }
  }
  /** Siguiente o anterior, saltando los canales ya marcados como caídos. */
  function step(d) {
    var n = P.items.length;
    if (!n) return;
    P.lastDir = d; P.zapping = true;
    var target = -1, i = P.index;
    for (var k = 1; k <= n; k++) {
      i = (i + d + n) % n;
      if (status[P.items[i].url] !== 2) { target = i; break; }
    }
    if (target < 0) { showBanner('No hay canales disponibles en esta lista'); return; }
    playIndex(target);
    for (var j = 1; j <= 8; j++) request(P.items[(((target + d * j) % n) + n) % n], scheduleRefresh);
  }
  function seek(sec) {
    if (isVod()) { video.currentTime = Math.max(0, Math.min(video.duration, video.currentTime + sec)); }
  }
  function togglePlay() { if (video.paused) { var p = video.play(); if (p && p.catch) p.catch(function () {}); } else video.pause(); }
  function toggleFullscreen() {
    var d = document, r = d.documentElement;
    if (d.fullscreenElement || d.webkitFullscreenElement) { (d.exitFullscreen || d.webkitExitFullscreen).call(d); }
    else if (r.requestFullscreen || r.webkitRequestFullscreen) { (r.requestFullscreen || r.webkitRequestFullscreen).call(r); }
  }
  function openChannelList() {
    openModal(P.label || 'Canales', function (box, list) {
      P.items.forEach(function (ch, i) {
        var s = status[ch.url];
        var b = el('button', 'row f' + (i === P.index ? ' cur' : ''), (i === P.index ? '▶ ' : '') + (s === 1 ? '✓  ' : s === 2 ? '✕  ' : '') + ch.name);
        b.onclick = function () { closeModal(); P.zapping = false; P.autoSkips = 0; playIndex(i); if (!TVL.tv) showControls(false); };
        list.appendChild(b);
      });
    }, [{ label: 'Cerrar', fn: closeModal }]);
  }
  function playerKey(e) {
    var k = e.keyCode, dir = dirOf(k), vis = controlsVisible();
    if (k === 427 || k === 33) { e.preventDefault(); step(1); return; }       // CH+
    if (k === 428 || k === 34) { e.preventDefault(); step(-1); return; }      // CH-
    if (k === 415) { e.preventDefault(); if (video.paused) togglePlay(); return; }
    if (k === 19 || k === 10252 || k === 179) { e.preventDefault(); togglePlay(); return; }
    if (k === 413) { e.preventDefault(); closePlayer(); return; }
    if (isBack(k) || k === 8) { e.preventDefault(); closePlayer(); return; }
    if (dir) {
      e.preventDefault();
      if (vis) { clearTimeout(P.ctrlTimer); P.ctrlTimer = setTimeout(hideControls, 4500); moveFocus(dir, $('controls')); return; }
      if (dir === 'up') step(-1);
      else if (dir === 'down') step(1);
      else seek(dir === 'left' ? -10 : 10);
      return;
    }
    if (k === 13 && !vis) { e.preventDefault(); showControls(true); }
  }
  function modalKey(e) {
    var k = e.keyCode, dir = dirOf(k), typing = e.target && e.target.tagName === 'INPUT';
    if (isBack(k)) { e.preventDefault(); closeModal(); return; }
    if (dir) {
      if (typing && (dir === 'left' || dir === 'right')) return;
      e.preventDefault(); moveFocus(dir, modalEl);
    }
  }

  // ---------- Arranque ----------
  function init() {
    appEl = $('app'); gridEl = $('grid'); searchEl = $('search'); countEl = $('count'); emptyEl = $('empty');
    chips1 = $('chips1'); chips2 = $('chips2'); modalEl = $('modal'); playerEl = $('player'); video = $('video');

    if (TVL.tv) show($('pFull'), false);

    searchEl.addEventListener('input', function () { applyFilter(); });
    $('btnOk').onclick = function () {
      onlyOk = !onlyOk;
      this.className = 'f chip' + (onlyOk ? ' on' : '');
      applyFilter();
    };
    $('btnLists').onclick = showMenu;

    window.addEventListener('scroll', function () {
      if (rendered < shown.length && window.innerHeight + window.pageYOffset > document.body.scrollHeight - 700) renderMore();
    });

    // Reproductor
    $('pBack').onclick = closePlayer;
    $('pPrev').onclick = function () { step(-1); showControls(false); };
    $('pNext').onclick = function () { step(1); showControls(false); };
    $('pRew').onclick = function () { seek(-10); showControls(false); };
    $('pFwd').onclick = function () { seek(10); showControls(false); };
    $('pPlay').onclick = function () { togglePlay(); showControls(false); };
    $('pList').onclick = openChannelList;
    $('pFull').onclick = toggleFullscreen;
    video.addEventListener('click', function () { if (controlsVisible()) hideControls(); else showControls(false); });
    video.addEventListener('dblclick', function () { if (!TVL.tv) toggleFullscreen(); });
    playerEl.addEventListener('mousemove', function () { if (!TVL.tv) showControls(false); });
    video.addEventListener('playing', function () {
      clearTimeout(P.startTimer); showSpin(false); P.autoSkips = 0;
      $('pPlay').textContent = 'Pausa';
      var ch = P.items[P.index];
      if (ch && ch.url.indexOf('ia://') !== 0) markStatus(ch.url, 1);
    });
    video.addEventListener('pause', function () { $('pPlay').textContent = 'Reproducir'; });
    video.addEventListener('play', function () { $('pPlay').textContent = 'Pausa'; });
    video.addEventListener('waiting', function () { showSpin(true); });
    video.addEventListener('canplay', function () { showSpin(false); });
    video.addEventListener('error', function () { onPlayError(); });
    video.addEventListener('timeupdate', function () {
      var vod = isVod();
      $('pTime').textContent = vod ? fmt(video.currentTime) + ' / ' + fmt(video.duration) : 'En vivo';
      $('pFill').style.width = vod ? (100 * video.currentTime / video.duration) + '%' : '0';
      show($('pRew'), vod); show($('pFwd'), vod);
    });

    // Teclado y control remoto
    document.addEventListener('keydown', function (e) {
      if (modalOpen()) { modalKey(e); return; }
      if (playerOpen()) { playerKey(e); return; }
      var k = e.keyCode, dir = dirOf(k), typing = e.target && e.target.tagName === 'INPUT';
      if (dir) {
        if (typing && (dir === 'left' || dir === 'right')) return;
        e.preventDefault(); moveFocus(dir, appEl); return;
      }
      if (k === 13 && e.target && e.target.tagName === 'DIV' && hasClass(e.target, 'card')) { e.preventDefault(); e.target.click(); return; }
      if (k === 10009 || k === 461) exitApp();
    });
    try {   // Samsung Tizen: pedir las teclas de canal y multimedia
      if (window.tizen && window.tizen.tvinputdevice) {
        ['ChannelUp', 'ChannelDown', 'MediaPlay', 'MediaPause', 'MediaPlayPause', 'MediaStop'].forEach(function (n) {
          try { window.tizen.tvinputdevice.registerKey(n); } catch (e) { /* nada */ }
        });
      }
    } catch (e) { /* nada */ }

    renderChips();
    select(DEFAULT);
    var first = document.querySelector('.f');
    if (TVL.tv && first) first.focus();
  }
  init();
})();
