window.TVL = { platform: 'samsung', tv: true };
