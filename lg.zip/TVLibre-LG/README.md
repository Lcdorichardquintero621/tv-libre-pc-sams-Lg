# TV Libre – LG webOS
Proyecto independiente. Se empaqueta como .ipk con ares-package.
