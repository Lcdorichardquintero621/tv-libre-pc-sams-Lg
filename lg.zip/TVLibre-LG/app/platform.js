window.TVL = { platform: 'lg', tv: true };
